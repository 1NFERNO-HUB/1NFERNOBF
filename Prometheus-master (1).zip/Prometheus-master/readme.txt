Known Bugs:
    Lua 5.2+ _ENV does not work

Info:
    Tables Constructors are treated the way they are in LuaU, meaning that every Value will be assigned in the order it programmed